
var stringA = "Hello, this is stringA!"
// stringA can be modified
let stringB = "Hello, this is stringB"
// stringB cannot be modified

if stringA.isEmpty {
    print( "stringA is empty!" )
} else {
    print( "stringA is not empty!" )
}

print(stringB)

var varA:Float = 20.0 // float data type
var constB = 100 // constant data type
var varC:Int = 10 // integer data type

print(varA)
print(constB)
print(varC)



